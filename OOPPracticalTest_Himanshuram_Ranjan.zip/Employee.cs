﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPPracticalTest
{
    public abstract class Employee
    {

        protected int empId { get; set; }
        protected string empName { get; set; }
        protected string address { get; set; }
        protected double basicPay { get; set; }

        public Employee(){
        }
        public Employee(int empId,string empName,string address,double basicPay)
        {
            this.empId = empId;
            this.empName = empName;
            this.address = address;
            this.basicPay = basicPay;
        }

        /// <summary>
        /// calculates the total salary
        /// </summary>
        /// <returns></returns>
        public abstract double calculateSalary();

        public override string ToString()
        {
            return $"Employee name is {empName} and Id is {empId}";
        }

    }
}
