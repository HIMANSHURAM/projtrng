﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPPracticalTest
{
    class TechnicalEmployee : Employee
    {
        protected string[] techSkills{ get; set; }
        

        public TechnicalEmployee(int empId, string empName, string address, double basicPay,string[] techSkills) : base(empId, empName, address, basicPay)
        {
            this.techSkills = techSkills;
        }

        /// <summary>
        /// calulates the total Salary
        /// </summary>
        /// <returns></returns>
        public override double calculateSalary()
        {
            double HRA = (0.12 * basicPay);
            double salary = basicPay + HRA;
            return salary;
        }

        /// <summary>
        /// display all the technical skills 
        /// </summary>
        /// <returns></returns>
        public string DisplaySkills()
        {
            string skills;
            skills=String.Join(", ", techSkills);

            return $"the skills are : {skills}";
        }

        /// <summary>
        /// shows the employee's name and id
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"Employee name is {empName} and Id is {empId}";
        }
    }
}
