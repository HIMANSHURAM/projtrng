﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPPracticalTest
{
    class Staff : Employee
    {
        protected string title { get; set; }

        public Staff(int empId, string empName, string address, double basicPay, string title) : base(empId, empName, address, basicPay)
        {
            this.title = title;
        }


        /// <summary>
        /// calculates the total salary
        /// </summary>
        /// <returns></returns>
        public override double calculateSalary()
        {
            double HRA = (0.18 * basicPay);
            double salary = basicPay + HRA;
            return salary;
        }

        /// <summary>
        /// return the employee's name and id
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"Employee name is {empName} and Id is {empId}";
        }
    }
}
