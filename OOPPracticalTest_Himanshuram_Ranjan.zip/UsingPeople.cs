﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPPracticalTest
{
    class UsingPeople
    {
        static void Main(string[] args)
        {
            
            string empName;
            int empId;
            string address;
            double basicpay;
            string title;
            string[] techSkills;
            string empProfile;

            // taking the inputs from user
            try
            {
                Console.WriteLine("Enter the name of the Employee");
                empName = Console.ReadLine();

                Console.WriteLine("Enter the id of the Employee");
                empId= int.Parse(Console.ReadLine());

                Console.WriteLine("Enter the address of the Employee");
                address = Console.ReadLine();

                Console.WriteLine("Enter the basic pay of the Employee");
                basicpay = double.Parse(Console.ReadLine());


                Console.WriteLine("Profile Type: Technical Employee or Staff");
                empProfile = Console.ReadLine();


                //instance of Staff class
                if (empProfile.Equals("Staff"))
                {
                    Console.WriteLine("Enter the title of the Employee");
                    title = Console.ReadLine();

                    Staff s = new Staff(empId, empName, address, basicpay, title);

                    Console.WriteLine();
                    Console.WriteLine(s.ToString());
                    Console.WriteLine($"The total salary of {empName} is {s.calculateSalary()}");
                }

                // instance of technical employee class
                else
                {
                    Console.WriteLine("Enter the technical skills of the Employee (separated by space)");
                    techSkills = Console.ReadLine().Split();

                    TechnicalEmployee te = new TechnicalEmployee(empId, empName, address, basicpay, techSkills);

                    Console.WriteLine();
                    Console.WriteLine(te.DisplaySkills());
                    Console.WriteLine(te.ToString());
                    Console.WriteLine($"The total salary of {empName} is {te.calculateSalary()}");
                }

            }

            catch(FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }

            catch(NotFiniteNumberException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


            finally
            {
                Console.WriteLine("Thank You for using the application!!!");
            }
        }
    }
}
